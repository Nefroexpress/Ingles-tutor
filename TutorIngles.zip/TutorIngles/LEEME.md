# Mi Tutor de Inglés 🇺🇸

App Android para aprender inglés y comunicarte, que funciona **sin conexión**.

## Qué hace

**1. ¿Cómo digo?** — Escribe o dicta en español y te dice cómo se dice en inglés, en voz alta (normal o lenta 🐢). Puedes guardar la frase ⭐ para practicarla. Con el interruptor "Al revés" traduce de inglés a español.

**2. Escuchar** — Acerca el teléfono a la persona que habla inglés: ves lo que dijo y la traducción al español. Con "Escucha continua" sigue escuchando frase tras frase. El botón **Responder** te deja hablar en español y el teléfono lo dice en inglés en voz alta para la otra persona. Toca un mensaje para oírlo otra vez; déjalo presionado para guardarlo.

**3. Tutor** — Lecciones por tema (saludos, restaurante, compras, viajes, trabajo, salud, conversación diaria). Ves la frase en español, intentas decirla en inglés y la app **califica tu pronunciación** y te dice qué palabras practicar. Se adapta a ti: guarda tus errores en "Repasar mis errores", tus frases guardadas, puntos, nivel y racha de días.

## Para que funcione 100 % sin internet (hacer UNA vez, con internet)

1. Abre la app con internet: descarga sola el traductor (unos 60 MB). Arriba dirá "✅ Listo · funciona sin internet".
2. Voz sin conexión para escuchar: en el teléfono ve a **Ajustes › Sistema › Idiomas › Reconocimiento de voz** (o abre la app de Google › Ajustes › Voz › **Reconocimiento de voz sin conexión**) y descarga **English (US)** y **Español**. El nombre exacto del menú cambia según la marca del teléfono.
3. Voz para hablar: **Ajustes › Accesibilidad › Texto a voz › Motor de Google › Instalar datos de voz** y descarga **English (United States)**.

## Cómo obtener el APK

### Opción A — Sin instalar nada (con GitHub, gratis)
1. Crea una cuenta en github.com y un repositorio nuevo.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`). Es más fácil desde una computadora: arrastra los archivos en "Add file › Upload files".
3. Entra a la pestaña **Actions**: se compila solo en unos 5 minutos.
4. Abre la ejecución terminada y descarga **MiTutorDeIngles-apk** (viene en .zip; adentro está el `.apk`).
5. Pasa el APK al teléfono, ábrelo y permite "instalar apps de origen desconocido".

### Opción B — Con Android Studio (computadora)
1. Instala Android Studio y abre esta carpeta (File › Open).
2. Espera a que sincronice y toca **Build › Build APK(s)**.
3. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Detalles técnicos
- Kotlin, minSdk 26 (Android 8+), targetSdk 34.
- Traducción: Google ML Kit Translate (en el dispositivo).
- Reconocimiento de voz: `SpeechRecognizer` de Android con preferencia sin conexión.
- Voz: `TextToSpeech` de Android.
- Las lecciones están en `app/src/main/java/com/tutor/ingles/Lessons.kt` — puedes agregar más frases ahí.
