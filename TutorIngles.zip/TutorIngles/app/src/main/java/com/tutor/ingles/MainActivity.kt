package com.tutor.ingles

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.time.LocalDate
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    // ---------- Motores ----------
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private val esToEn: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.SPANISH)
            .setTargetLanguage(TranslateLanguage.ENGLISH)
            .build()
    )
    private val enToEs: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.SPANISH)
            .build()
    )
    private var modelsReady = false

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pendingListen: (() -> Unit)? = null
    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) pendingListen?.invoke()
            else toast("Necesito permiso del micrófono para escuchar")
            pendingListen = null
        }

    private lateinit var prefs: SharedPreferences

    // ---------- Vistas ----------
    private lateinit var tvStatus: TextView
    private lateinit var tvListening: TextView
    private lateinit var sections: List<View>

    // ¿Cómo digo?
    private lateinit var swReverse: SwitchCompat
    private lateinit var etAsk: EditText
    private lateinit var answerBox: View
    private lateinit var tvAnswer: TextView
    private var lastSource = ""
    private var lastAnswer = ""

    // Escuchar
    private lateinit var btnListen: Button
    private lateinit var swContinuous: SwitchCompat
    private lateinit var tvPartial: TextView
    private lateinit var transcript: LinearLayout
    private var conversationActive = false

    // Tutor
    private lateinit var tvStats: TextView
    private lateinit var spCategory: Spinner
    private lateinit var tvCounter: TextView
    private lateinit var tvPhraseEs: TextView
    private lateinit var tvPhraseEn: TextView
    private lateinit var tvFeedback: TextView
    private var phrases: List<Phrase> = emptyList()
    private var index = 0
    private var revealed = false

    companion object {
        const val CAT_MINE = "⭐ Mis frases guardadas"
        const val CAT_REVIEW = "🔁 Repasar mis errores"
    }

    // =====================================================================
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("tutor", MODE_PRIVATE)
        tts = TextToSpeech(this, this)

        tvStatus = findViewById(R.id.tvStatus)
        tvListening = findViewById(R.id.tvListening)
        sections = listOf(
            findViewById(R.id.sectionAsk),
            findViewById(R.id.sectionListen),
            findViewById(R.id.sectionTutor)
        )

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener { item ->
            stopListening()
            val target = when (item.itemId) {
                R.id.nav_listen -> 1
                R.id.nav_tutor -> 2
                else -> 0
            }
            sections.forEachIndexed { i, v -> v.visibility = if (i == target) View.VISIBLE else View.GONE }
            if (target == 2) refreshStats()
            true
        }

        setupAsk()
        setupListen()
        setupTutor()
        downloadModels()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        esToEn.close()
        enToEs.close()
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        stopListening()
    }

    // =====================================================================
    // Traductor sin conexión (ML Kit)
    // =====================================================================
    private fun downloadModels() {
        tvStatus.text = "⏳ Preparando el traductor sin conexión…"
        val conditions = DownloadConditions.Builder().build()
        esToEn.downloadModelIfNeeded(conditions)
            .onSuccessTask { enToEs.downloadModelIfNeeded(conditions) }
            .addOnSuccessListener {
                modelsReady = true
                tvStatus.text = "✅ Listo · funciona sin internet"
            }
            .addOnFailureListener {
                tvStatus.text =
                    "⚠️ Conéctate a internet una vez para descargar el traductor. Toca aquí para reintentar."
            }
        tvStatus.setOnClickListener { if (!modelsReady) downloadModels() }
    }

    private fun translate(text: String, toEnglish: Boolean, onDone: (String) -> Unit) {
        val t = if (toEnglish) esToEn else enToEs
        t.translate(text)
            .addOnSuccessListener { onDone(it) }
            .addOnFailureListener {
                toast("No pude traducir. Si es la primera vez, conéctate a internet para descargar el traductor.")
            }
    }

    // =====================================================================
    // Voz: hablar (TextToSpeech)
    // =====================================================================
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val r = tts.setLanguage(Locale.US)
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) toast("Instala la voz en inglés: Ajustes › Accesibilidad › Texto a voz")
        } else {
            toast("Este teléfono no tiene motor de voz. Instala 'Speech Services by Google'.")
        }
    }

    private fun speak(text: String, slow: Boolean = false) {
        if (!ttsReady) {
            toast("La voz en inglés no está lista")
            return
        }
        stopListening()
        tts.setSpeechRate(if (slow) 0.55f else 0.95f)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
    }

    // =====================================================================
    // Voz: escuchar (SpeechRecognizer, prefiere modo sin conexión)
    // =====================================================================
    private fun listen(
        language: String,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onEnd: () -> Unit = {}
    ) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingListen = { listen(language, onPartial, onFinal, onEnd) }
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Este teléfono no tiene reconocimiento de voz. Instala la app de Google.")
            return
        }
        if (::tts.isInitialized) tts.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = setListeningUi(true)
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()?.takeIf { it.isNotBlank() }?.let(onPartial)
            }

            override fun onResults(results: Bundle?) {
                setListeningUi(false)
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onFinal(text)
                onEnd()
            }

            override fun onError(error: Int) {
                setListeningUi(false)
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_CLIENT ||
                        error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY
                if (!quiet) {
                    toast(errorText(error))
                    conversationActive = false
                    updateListenButton()
                }
                onEnd()
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        r.startListening(intent)
    }

    private fun stopListening() {
        conversationActive = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        if (::tvListening.isInitialized) setListeningUi(false)
        if (::btnListen.isInitialized) updateListenButton()
    }

    private fun setListeningUi(on: Boolean) {
        tvListening.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun errorText(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER,
        12, 13 -> // idioma no disponible sin conexión
            "Sin internet: descarga el reconocimiento de voz sin conexión (inglés y español). Mira el archivo LEEME."
        SpeechRecognizer.ERROR_AUDIO -> "Problema con el micrófono"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso del micrófono"
        else -> "No te escuché bien, intenta otra vez"
    }

    // =====================================================================
    // 1. ¿CÓMO DIGO?
    // =====================================================================
    private fun setupAsk() {
        swReverse = findViewById(R.id.swReverse)
        etAsk = findViewById(R.id.etAsk)
        answerBox = findViewById(R.id.answerBox)
        tvAnswer = findViewById(R.id.tvAnswer)

        swReverse.setOnCheckedChangeListener { _, reversed ->
            etAsk.hint = if (reversed) "Ej: Where can I catch the bus?" else "Ej: ¿Dónde puedo tomar el autobús?"
            answerBox.visibility = View.GONE
        }

        findViewById<Button>(R.id.btnTranslate).setOnClickListener { doAskTranslate() }

        findViewById<Button>(R.id.btnDictate).setOnClickListener {
            val lang = if (swReverse.isChecked) "en-US" else "es-ES"
            listen(lang,
                onPartial = { etAsk.setText(it) },
                onFinal = {
                    etAsk.setText(it)
                    doAskTranslate()
                })
        }

        findViewById<Button>(R.id.btnSay).setOnClickListener { speak(englishOfAsk()) }
        findViewById<Button>(R.id.btnSlow).setOnClickListener { speak(englishOfAsk(), slow = true) }
        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            cm.setPrimaryClip(ClipData.newPlainText("traduccion", lastAnswer))
            toast("Copiado")
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            if (lastAnswer.isBlank()) return@setOnClickListener
            val p = if (swReverse.isChecked) Phrase(lastAnswer, lastSource) else Phrase(lastSource, lastAnswer)
            saveMyPhrase(p)
            toast("⭐ Guardada. Practícala en Tutor › Mis frases")
        }
    }

    private fun englishOfAsk(): String = if (swReverse.isChecked) lastSource else lastAnswer

    private fun doAskTranslate() {
        val text = etAsk.text.toString().trim()
        if (text.isEmpty()) {
            toast("Escribe o dicta algo primero")
            return
        }
        val toEnglish = !swReverse.isChecked
        translate(text, toEnglish) { result ->
            lastSource = text
            lastAnswer = result
            tvAnswer.text = result
            answerBox.visibility = View.VISIBLE
            speak(englishOfAsk())
        }
    }

    // =====================================================================
    // 2. ESCUCHAR Y CONVERSAR
    // =====================================================================
    private fun setupListen() {
        btnListen = findViewById(R.id.btnListen)
        swContinuous = findViewById(R.id.swContinuous)
        tvPartial = findViewById(R.id.tvPartial)
        transcript = findViewById(R.id.transcript)

        btnListen.setOnClickListener {
            if (conversationActive) {
                stopListening()
            } else {
                conversationActive = true
                updateListenButton()
                listenEnglishLoop()
            }
        }

        findViewById<Button>(R.id.btnReply).setOnClickListener {
            stopListening()
            tvPartial.text = "Habla en español…"
            listen("es-ES",
                onPartial = { tvPartial.text = "🗣️ $it" },
                onFinal = { spanish ->
                    tvPartial.text = ""
                    translate(spanish, toEnglish = true) { english ->
                        addBubble(english = english, spanish = spanish, mine = true)
                        speak(english) // el teléfono lo dice en voz alta para la otra persona
                    }
                },
                onEnd = { if (tvPartial.text.startsWith("Habla")) tvPartial.text = "" })
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener { transcript.removeAllViews() }
    }

    private fun listenEnglishLoop() {
        if (!conversationActive) return
        tvPartial.text = "Escuchando inglés…"
        listen("en-US",
            onPartial = { tvPartial.text = "👂 $it" },
            onFinal = { english ->
                tvPartial.text = ""
                translate(english, toEnglish = false) { spanish ->
                    addBubble(english = english, spanish = spanish, mine = false)
                }
            },
            onEnd = {
                if (conversationActive && swContinuous.isChecked) {
                    handler.postDelayed({ listenEnglishLoop() }, 250)
                } else {
                    conversationActive = false
                    updateListenButton()
                    if (tvPartial.text.startsWith("Escuchando")) tvPartial.text = ""
                }
            })
    }

    private fun updateListenButton() {
        btnListen.text = if (conversationActive) "⏹️ Detener" else "🎧 Escuchar inglés"
    }

    private fun addBubble(english: String, spanish: String, mine: Boolean) {
        val tv = TextView(this).apply {
            text = if (mine) "🗣️ Tú: $spanish\n🇺🇸 $english" else "👤 $english\n🇪🇸 $spanish"
            textSize = 18f
            setTextColor(ContextCompat.getColor(this@MainActivity, R.color.text))
            val pad = (14 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            setBackgroundResource(if (mine) R.drawable.bubble_me else R.drawable.bubble_them)
            setOnClickListener { speak(english) }
            setOnLongClickListener {
                saveMyPhrase(Phrase(spanish, english))
                toast("⭐ Guardada para practicar")
                true
            }
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (10 * resources.displayMetrics.density).toInt() }
        transcript.addView(tv, 0, lp) // lo más nuevo arriba
    }

    // =====================================================================
    // 3. TUTOR PERSONALIZADO
    // =====================================================================
    private fun setupTutor() {
        tvStats = findViewById(R.id.tvStats)
        spCategory = findViewById(R.id.spCategory)
        tvCounter = findViewById(R.id.tvCounter)
        tvPhraseEs = findViewById(R.id.tvPhraseEs)
        tvPhraseEn = findViewById(R.id.tvPhraseEn)
        tvFeedback = findViewById(R.id.tvFeedback)

        val names = Lessons.categories.keys.toMutableList().apply {
            add(CAT_MINE)
            add(CAT_REVIEW)
        }
        spCategory.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                loadCategory(names[pos])
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        tvPhraseEn.setOnClickListener { reveal() }
        findViewById<Button>(R.id.btnReveal).setOnClickListener { reveal() }
        findViewById<Button>(R.id.btnPhraseSay).setOnClickListener {
            current()?.let { reveal(); speak(it.en) }
        }
        findViewById<Button>(R.id.btnPhraseSlow).setOnClickListener {
            current()?.let { reveal(); speak(it.en, slow = true) }
        }
        findViewById<Button>(R.id.btnNext).setOnClickListener { move(1) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { move(-1) }
        findViewById<Button>(R.id.btnPractice).setOnClickListener { practice() }

        refreshStats()
    }

    private fun loadCategory(name: String) {
        phrases = when (name) {
            CAT_MINE -> loadMyPhrases()
            CAT_REVIEW -> loadReview()
            else -> Lessons.categories[name].orEmpty()
        }
        index = 0
        showPhrase()
    }

    private fun current(): Phrase? = phrases.getOrNull(index)

    private fun move(step: Int) {
        if (phrases.isEmpty()) return
        index = (index + step + phrases.size) % phrases.size
        showPhrase()
    }

    private fun showPhrase() {
        revealed = false
        tvFeedback.text = ""
        val p = current()
        if (p == null) {
            tvCounter.text = ""
            tvPhraseEs.text = when (spCategory.selectedItem) {
                CAT_MINE -> "Aún no tienes frases guardadas. Toca ⭐ en «¿Cómo digo?» o deja presionado un mensaje en «Escuchar»."
                CAT_REVIEW -> "¡No tienes errores pendientes! 🎉"
                else -> ""
            }
            tvPhraseEn.text = ""
            return
        }
        tvCounter.text = "Frase ${index + 1} de ${phrases.size} · ¿Cómo se dice en inglés?"
        tvPhraseEs.text = p.es
        tvPhraseEn.text = "👀 Toca para ver"
    }

    private fun reveal() {
        val p = current() ?: return
        revealed = true
        tvPhraseEn.text = p.en
    }

    private fun practice() {
        val p = current() ?: return
        tvFeedback.text = "🎤 Di en inglés: «${p.es}»"
        listen("en-US",
            onPartial = { tvFeedback.text = "👂 $it" },
            onFinal = { heard -> grade(p, heard) })
    }

    private fun grade(p: Phrase, heard: String) {
        val score = (similarity(normalize(heard), normalize(p.en)) * 100).roundToInt()
        val targetWords = normalize(p.en).split(" ").filter { it.isNotBlank() }
        val heardWords = normalize(heard).split(" ").toSet()
        val missing = targetWords.filter { it !in heardWords }

        val sb = StringBuilder()
        sb.append("Escuché: «$heard»\n")
        when {
            score >= 85 -> sb.append("🎉 ¡Excelente! $score%")
            score >= 60 -> sb.append("👍 ¡Bien! $score% — casi perfecto")
            else -> sb.append("💪 $score% — escúchala con 🐢 y vuelve a intentar")
        }
        if (missing.isNotEmpty() && score < 100) {
            sb.append("\nPractica estas palabras: ${missing.joinToString(", ")}")
        }
        tvFeedback.text = sb.toString()
        reveal()

        // Personalización: guardar progreso y errores
        val good = score >= 85
        val e = prefs.edit()
        e.putInt("practiced", prefs.getInt("practiced", 0) + 1)
        e.putInt("points", prefs.getInt("points", 0) + when {
            score >= 85 -> 10
            score >= 60 -> 5
            else -> 1
        })
        val review = prefs.getStringSet("review", emptySet())!!.toMutableSet()
        val key = encode(p)
        if (good) review.remove(key) else review.add(key)
        e.putStringSet("review", review)
        e.apply()
        updateStreak()
        refreshStats()
        if (good) handler.postDelayed({ speak("Great job!") }, 200)
    }

    private fun updateStreak() {
        val today = LocalDate.now()
        val last = prefs.getString("lastDay", null)?.let { LocalDate.parse(it) }
        val streak = when (last) {
            today -> prefs.getInt("streak", 1)
            today.minusDays(1) -> prefs.getInt("streak", 0) + 1
            else -> 1
        }
        prefs.edit().putString("lastDay", today.toString()).putInt("streak", streak).apply()
    }

    private fun refreshStats() {
        if (!::tvStats.isInitialized) return
        val points = prefs.getInt("points", 0)
        val level = when {
            points < 100 -> "Principiante 🌱"
            points < 400 -> "Básico 🌿"
            points < 1000 -> "Intermedio 🌳"
            else -> "Avanzado 🏆"
        }
        val last = prefs.getString("lastDay", null)?.let { LocalDate.parse(it) }
        val alive = last != null && !last.isBefore(LocalDate.now().minusDays(1))
        val streak = if (alive) prefs.getInt("streak", 0) else 0
        val review = prefs.getStringSet("review", emptySet())!!.size
        tvStats.text = "Nivel: $level\n⭐ $points puntos · 🔥 Racha: $streak día(s)\n" +
                "🎤 Practicadas: ${prefs.getInt("practiced", 0)} · 🔁 Para repasar: $review"
    }

    // ---------- Guardado de frases ----------
    private fun encode(p: Phrase) = "${p.es}\u0001${p.en}"
    private fun decode(s: String): Phrase? =
        s.split("\u0001").takeIf { it.size == 2 }?.let { Phrase(it[0], it[1]) }

    private fun saveMyPhrase(p: Phrase) {
        val list = loadMyPhrases().toMutableList()
        if (list.none { it.en.equals(p.en, ignoreCase = true) }) list.add(p)
        prefs.edit().putString("mine", list.joinToString("\u0002") { encode(it) }).apply()
    }

    private fun loadMyPhrases(): List<Phrase> =
        prefs.getString("mine", "").orEmpty()
            .split("\u0002").filter { it.isNotBlank() }.mapNotNull { decode(it) }

    private fun loadReview(): List<Phrase> =
        prefs.getStringSet("review", emptySet())!!.mapNotNull { decode(it) }.shuffled()

    // ---------- Comparación de pronunciación ----------
    private fun normalize(s: String): String =
        s.lowercase(Locale.US)
            .replace("’", "'")
            .replace(Regex("[^a-z0-9' ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() && b.isEmpty()) return 1.0
        val d = levenshtein(a, b)
        return 1.0 - d.toDouble() / max(a.length, b.length)
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
